using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Facebook.Web")]
[assembly: AssemblyDescription("Facebook C# SDK")]
[assembly: AssemblyCompany("Thuzi")]
[assembly: AssemblyProduct("Facebook C# SDK")]
[assembly: AssemblyCopyright("Microsoft Public License (Ms-PL)")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("5.0.50.0")]

