﻿namespace Facebook.Extensions.Tests
{
    using Xunit;

    public class UnitTest1
    {
        [Fact]
        public void TestMethod1()
        {
        }
    }
}
