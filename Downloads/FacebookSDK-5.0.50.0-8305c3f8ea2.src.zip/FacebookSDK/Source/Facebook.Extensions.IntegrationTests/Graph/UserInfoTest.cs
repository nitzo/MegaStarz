﻿namespace Facebook.Extensions.Tests.Graph
{
    using Xunit;

    public class UserInfoTest
    {
        [Fact]
        public void TestMethod1()
        {
        }
    }
}
