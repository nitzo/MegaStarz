﻿// --------------------------------
// <copyright file="FacebookClient.cs" company="Thuzi LLC (www.thuzi.com)">
//     Microsoft Public License (Ms-PL)
// </copyright>
// <author>Nathan Totten (ntotten.com), Jim Zimmerman (jimzimmerman.com) and Prabir Shrestha (prabir.me)</author>
// <license>Released under the terms of the Microsoft Public License (Ms-PL)</license>
// <website>http://facebooksdk.codeplex.com</website>
// ---------------------------------

namespace Facebook
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Diagnostics.Contracts;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;

    /// <summary>
    /// Provides access to the Facebook Platform.
    /// </summary>
    public class FacebookClient
    {
        /// <summary>
        /// Indcates whether to use Facebook beta.
        /// </summary>
        private bool _useFacebookBeta = FacebookApplication.Current.UseFacebookBeta;

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookClient"/> class. 
        /// </summary>
        public FacebookClient()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookClient"/> class. 
        /// </summary>
        /// <param name="accessToken">
        /// The Facebook access token.
        /// </param>
        public FacebookClient(string accessToken)
        {
            Contract.Requires(!String.IsNullOrEmpty(accessToken));
            AccessToken = accessToken;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookClient"/> class.
        /// </summary>
        /// <param name="appId">
        /// The app id.
        /// </param>
        /// <param name="appSecret">
        /// The app secret.
        /// </param>
        public FacebookClient(string appId, string appSecret)
            : this(string.Concat(appId, "|", appSecret))
        {
            Contract.Requires(!string.IsNullOrEmpty(appId));
            Contract.Requires(!string.IsNullOrEmpty(appSecret));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookClient"/> class.
        /// </summary>
        /// <param name="facebookApplication">
        /// The facebook application.
        /// </param>
        public FacebookClient(IFacebookApplication facebookApplication)
        {
            if (facebookApplication != null)
            {
                if (!string.IsNullOrEmpty(facebookApplication.AppId) && !string.IsNullOrEmpty(facebookApplication.AppSecret))
                {
                    this.AccessToken = string.Concat(facebookApplication.AppId, "|", facebookApplication.AppSecret);
                }
            }
        }

        /// <summary>
        /// Event handler for delete completion.
        /// </summary>
        public event EventHandler<FacebookApiEventArgs> DeleteCompleted;

        /// <summary>
        /// Event handler for post completion.
        /// </summary>
        public event EventHandler<FacebookApiEventArgs> PostCompleted;

        /// <summary>
        /// Event handler for get completion.
        /// </summary>
        public event EventHandler<FacebookApiEventArgs> GetCompleted;

        /// <summary>
        /// Gets or sets the access token.
        /// </summary>
        public virtual string AccessToken { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to use Facebook beta.
        /// </summary>
        public virtual bool UseFacebookBeta
        {
            get { return _useFacebookBeta; }
            set { _useFacebookBeta = value; }
        }

        /// <summary>
        /// Gets the list of query parameters that get automatically dropped when rebuilding the current URL.
        /// </summary>
        protected virtual ICollection<string> DropQueryParameters
        {
            get
            {
                Contract.Ensures(Contract.Result<ICollection<string>>() != null);
                return FacebookUtils.DropQueryParameters;
            }
        }

        /// <summary>
        /// Gets the aliases to Facebook domains.
        /// </summary>
        protected virtual Dictionary<string, Uri> DomainMaps
        {
            get
            {
                Contract.Ensures(Contract.Result<Dictionary<string, Uri>>() != null);

                return UseFacebookBeta ? FacebookUtils.DomainMapsBeta : FacebookUtils.DomainMaps;
            }
        }

        #region Get/Post/Delete Methods

#if (!SILVERLIGHT) // Silverlight should only have async calls

        /// <summary>
        /// Makes a DELETE request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <returns>
        /// The json result.
        /// </returns>
        /// <exception cref="Facebook.FacebookApiException" />
        public virtual object Delete(string path)
        {
            Contract.Requires(!String.IsNullOrEmpty(path));

            return Api(path, null, HttpMethod.Delete, null);
        }

        /// <summary>
        /// Makes a DELETE request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The json result.
        /// </returns>
        /// <exception cref="Facebook.FacebookApiException" />
        public virtual object Delete(string path, IDictionary<string, object> parameters)
        {
            return Api(path, parameters, HttpMethod.Delete, null);
        }

        /// <summary>
        /// Makes a GET requst to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <returns>
        /// The json result.
        /// </returns>
        /// <exception cref="Facebook.FacebookApiException"/>
        public virtual object Get(string path)
        {
            Contract.Requires(!String.IsNullOrEmpty(path));

            return Api(path, null, HttpMethod.Get, null);
        }

        /// <summary>
        /// Makes a GET request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException"/>
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Get(string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            return Api(path, parameters, HttpMethod.Get, null);
        }

        /// <summary>
        /// Makes a GET request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException"/>
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Get(IDictionary<string, object> parameters)
        {
            Contract.Requires(parameters != null);

            return Api(null, parameters, HttpMethod.Get, null);
        }

        /// <summary>
        /// Makes a GET request to the Facebook server.
        /// </summary>
        /// <typeparam name="T">
        /// The result of the API call.
        /// </typeparam>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException"/>
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual T Get<T>(string path)
        {
            Contract.Requires(!String.IsNullOrEmpty(path));

            return Api<T>(path, null, HttpMethod.Get);
        }

        /// <summary>
        /// Makes a GET request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <typeparam name="T">
        /// The result of the API call.
        /// </typeparam>
        /// <exception cref="Facebook.FacebookApiException"/>
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual T Get<T>(string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            return Api<T>(path, parameters, HttpMethod.Get);
        }

        /// <summary>
        /// Makes a GET request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <typeparam name="T">
        /// The result of the API call.
        /// </typeparam>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual T Get<T>(IDictionary<string, object> parameters)
        {
            Contract.Requires(parameters != null);

            return Api<T>(null, parameters, HttpMethod.Get);
        }

        /// <summary>
        /// Makes a POST request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Post(string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            return Api(path, parameters, HttpMethod.Post, null);
        }


        /// <summary>
        /// Makes a POST request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Post(IDictionary<string, object> parameters)
        {
            Contract.Requires(parameters != null);

            return Api(null, parameters, HttpMethod.Post, null);
        }


        /// <summary>
        /// Makes a POST request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Post(object parameters)
        {
            Contract.Requires(parameters != null);
            if (parameters is IDictionary<string, object>)
            {
                return Post((IDictionary<string, object>)parameters);
            }
            else if (parameters is string)
            {
                return Post((string)parameters, null);
            }

            return Post(FacebookUtils.ToDictionary(parameters));
        }

        /// <summary>
        /// Makes a POST request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Post(string path, object parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            if (parameters is IDictionary<string, object>)
            {
                return Post(path, (IDictionary<string, object>)parameters);
            }

            return Post(path, FacebookUtils.ToDictionary(parameters));
        }

#endif

        #endregion

        #region Async Get/Post/Delete Methods

        /// <summary>
        /// Makes an asynchronous DELETE request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        public virtual void DeleteAsync(string path)
        {
            Contract.Requires(!String.IsNullOrEmpty(path));

            DeleteAsync(path, null);
        }

        /// <summary>
        /// Makes an asynchronous DELETE request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void DeleteAsync(string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            DeleteAsync(path, parameters, null);
        }

        /// <summary>
        /// Makes an asynchronous DELETE request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <param name="userToken">
        /// The user token.
        /// </param>
        public virtual void DeleteAsync(string path, IDictionary<string, object> parameters, object userToken)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            ApiAsync(path, parameters, HttpMethod.Delete, userToken);
        }

        /// <summary>
        /// Makes an asynchronous GET request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        public virtual void GetAsync(string path)
        {
            Contract.Requires(!String.IsNullOrEmpty(path));

            GetAsync(path, null);
        }

        /// <summary>
        /// Makes an asynchronous GET request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void GetAsync(string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            GetAsync(path, parameters, null);
        }

        /// <summary>
        /// Makes an asynchronous GET request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <param name="userToken">
        /// The user token.
        /// </param>
        public virtual void GetAsync(string path, IDictionary<string, object> parameters, object userToken)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            ApiAsync(path, parameters, HttpMethod.Get, userToken);
        }

        /// <summary>
        /// Makes an asynchronous GET request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void GetAsync(IDictionary<string, object> parameters)
        {
            Contract.Requires(parameters != null);

            GetAsync(null, parameters);
        }

        /// <summary>
        /// Makes an asynchronous POST request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void PostAsync(string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            PostAsync(path, parameters, null);
        }

        /// <summary>
        /// Makes an asynchronous POST request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <param name="userToken">
        /// The user token.
        /// </param>
        public virtual void PostAsync(string path, IDictionary<string, object> parameters, object userToken)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            ApiAsync(path, parameters, HttpMethod.Post, userToken);
        }

        /// <summary>
        /// Makes an asynchronous POST request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void PostAsync(IDictionary<string, object> parameters)
        {
            Contract.Requires(parameters != null);

            PostAsync(null, parameters);
        }

        /// <summary>
        /// Makes an asynchronous POST request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void PostAsync(string path, object parameters)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            if (parameters is IDictionary<string, object>)
            {
                PostAsync(path, (IDictionary<string, object>)parameters);
            }
            else
            {
                PostAsync(path, FacebookUtils.ToDictionary(parameters));
            }
        }

        /// <summary>
        /// Makes an asynchronous POST request to the Facebook server.
        /// </summary>
        /// <param name="path">
        /// The resource path.
        /// </param>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <param name="userToken">
        /// The user token.
        /// </param>
        public virtual void PostAsync(string path, object parameters, object userToken)
        {
            Contract.Requires(!(String.IsNullOrEmpty(path) && parameters == null));

            if (parameters is IDictionary<string, object>)
            {
                PostAsync(path, (IDictionary<string, object>)parameters, userToken);
            }
            else
            {
                PostAsync(path, FacebookUtils.ToDictionary(parameters), userToken);
            }
        }

        /// <summary>
        /// Makes an asynchronous POST request to the Facebook server.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        public virtual void PostAsync(object parameters)
        {
            Contract.Requires(parameters != null);

            if (parameters is IDictionary<string, object>)
            {
                PostAsync((IDictionary<string, object>)parameters);
            }
            else if (parameters is string)
            {
                PostAsync((string)parameters, null);
            }
            else
            {
                PostAsync(FacebookUtils.ToDictionary(parameters));
            }
        }

        #endregion

        #region Query (FQL)

#if (!SILVERLIGHT)

        /// <summary>
        /// Executes a FQL query.
        /// </summary>
        /// <param name="fql">
        /// The FQL query.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// The FQL query result.
        /// </returns>
        public virtual object Query(string fql)
        {
            Contract.Requires(!String.IsNullOrEmpty(fql));

            var parameters = new Dictionary<string, object>();
            parameters["query"] = fql;
            parameters["method"] = "fql.query";

            return Get(parameters);
        }

        /// <summary>
        /// Executes a FQL multiquery.
        /// </summary>
        /// <param name="fql">
        /// The FQL queries.
        /// </param>
        /// <exception cref="Facebook.FacebookApiException" />
        /// <returns>
        /// A collection of the FQL query results.
        /// </returns>
        public virtual object Query(params string[] fql)
        {
            Contract.Requires(fql != null);

            var queryDict = new Dictionary<string, object>();

            for (int i = 0; i < fql.Length; i++)
            {
                queryDict.Add(string.Concat("query", i), fql[i]);
            }

            var parameters = new Dictionary<string, object>();
            parameters["queries"] = queryDict;
            parameters["method"] = "fql.multiquery";

            return Get(parameters);
        }
#endif

        /// <summary>
        /// Executes a FQL query asynchronously.
        /// </summary>
        /// <param name="fql">
        /// The FQL query.
        /// </param>
        public virtual void QueryAsync(string fql)
        {
            Contract.Requires(!String.IsNullOrEmpty(fql));

            QueryAsync(fql, null);
        }

        /// <summary>
        /// Executes a FQL query asynchronously.
        /// </summary>
        /// <param name="fql">
        /// The FQL query.
        /// </param>
        /// <param name="userToken">
        /// The user token.
        /// </param>
        public virtual void QueryAsync(string fql, object userToken)
        {
            Contract.Requires(!String.IsNullOrEmpty(fql));

            var parameters = new Dictionary<string, object>();
            parameters["query"] = fql;
            parameters["method"] = "fql.query";

            GetAsync(null, parameters, userToken);
        }

        /// <summary>
        /// Executes a FQL multiquery asynchronously.
        /// </summary>
        /// <param name="fql">
        /// The FQL queries.
        /// </param>
        public virtual void QueryAsync(string[] fql)
        {
            Contract.Requires(fql != null);
            Contract.Requires(fql.Length > 0);

            QueryAsync(fql, null);
        }

        /// <summary>
        /// Executes a FQL multiquery asynchronously.
        /// </summary>
        /// <param name="fql">
        /// The FQL queries.
        /// </param>
        /// <param name="userToken">
        /// The user Token.
        /// </param>
        public virtual void QueryAsync(string[] fql, object userToken)
        {
            Contract.Requires(fql != null);
            Contract.Requires(fql.Length > 0);

            var queryDict = new Dictionary<string, object>();
            for (int i = 0; i < fql.Length; i++)
            {
                queryDict.Add(string.Concat("query", i), fql[i]);
            }

            var parameters = new Dictionary<string, object>();
            parameters["queries"] = queryDict;
            parameters["method"] = "fql.multiquery";

            GetAsync(null, parameters, userToken);
        }

        #endregion

        #region Batch Requests

#if !SILVERLIGHT

        /// <summary>
        /// Executes a batch request.
        /// </summary>
        /// <param name="batchParameters">
        /// The batch parameters.
        /// </param>
        /// <returns>
        /// The json result.
        /// </returns>
        public virtual object Batch(params FacebookBatchParameter[] batchParameters)
        {
            Contract.Requires(batchParameters != null);
            Contract.Requires(batchParameters.Length > 0);

            return ProcessBatchResult(Post(PrepareBatchParameter(batchParameters)));
        }

#endif

        /// <summary>
        /// Executes a batch request asynchronously.
        /// </summary>
        /// <param name="batchParameters">
        /// The batch parameters.
        /// </param>
        /// <param name="userToken">
        /// The user token.
        /// </param>
        public virtual void BatchAsync(FacebookBatchParameter[] batchParameters, object userToken)
        {
            Contract.Requires(batchParameters != null);
            Contract.Requires(batchParameters.Length > 0);

            PostAsync(null, PrepareBatchParameter(batchParameters), userToken);
        }

        internal IDictionary<string, object> PrepareBatchParameter(FacebookBatchParameter[] batchParameters)
        {
            Contract.Requires(batchParameters != null);
            Contract.Requires(batchParameters.Length > 0);

            var actualParameters = new Dictionary<string, object>();
            var parameters = new List<object>();

            foreach (var parameter in batchParameters)
            {
                IDictionary<string, FacebookMediaObject> mediaObjects;
                parameters.Add(ToParameters(parameter, out mediaObjects));

                if (mediaObjects != null)
                {
                    foreach (var facebookMediaObject in mediaObjects)
                    {
                        actualParameters.Add(facebookMediaObject.Key, facebookMediaObject.Value);
                    }
                }
            }

            actualParameters["batch"] = JsonSerializer.Current.SerializeObject(parameters);

            return actualParameters;
        }

        /// <summary>
        /// Executes a batch request asynchronously.
        /// </summary>
        /// <param name="batchParameters">
        /// The batch parameters.
        /// </param>
        public virtual void BatchAsync(FacebookBatchParameter[] batchParameters)
        {
            Contract.Requires(batchParameters != null);
            Contract.Requires(batchParameters.Length > 0);

            BatchAsync(batchParameters, null);
        }

        /// <summary>
        /// Converts the facebook batch to POST parameters.
        /// </summary>
        /// <param name="batchParameter">
        /// The batch parameter.
        /// </param>
        /// <returns>
        /// The post parameters.
        /// </returns>
        protected IDictionary<string, object> ToParameters(FacebookBatchParameter batchParameter, out IDictionary<string, FacebookMediaObject> mediaObjects)
        {
            Contract.Requires(batchParameter != null);
            Contract.Ensures(Contract.Result<IDictionary<string, object>>() != null);

            mediaObjects = null;
            IDictionary<string, object> returnResult = null;

            var defaultParameters = new Dictionary<string, object>();

            defaultParameters["method"] = FacebookUtils.ConvertToStringForce(batchParameter.HttpMethod);

            IDictionary<string, object> parameters = null;
            if (batchParameter.Parameters == null)
            {
                parameters = new Dictionary<string, object>();
            }
            else
            {
                if (batchParameter.Parameters is IDictionary<string, object>)
                {
                    parameters = (IDictionary<string, object>)batchParameter.Parameters;
                    mediaObjects = ExtractMediaObjects(parameters);
                    if (mediaObjects.Count == 1)
                    {
                        defaultParameters["attached_files"] = mediaObjects.ElementAt(0).Key;
                    }
                }
                else
                {
                    parameters = FacebookUtils.ToDictionary(batchParameter.Parameters);
                }
            }

            var path = FacebookUtils.ParseQueryParametersToDictionary(batchParameter.Path, parameters);
            string queryString = string.Empty;
            if (batchParameter.HttpMethod == HttpMethod.Get)
            {
                queryString = FacebookUtils.ToJsonQueryString(parameters);
            }
            else
            {
                defaultParameters["body"] = FacebookUtils.ToJsonQueryString(parameters);
            }

            var relativeUrl = new StringBuilder(path);
            if (!string.IsNullOrEmpty(queryString))
            {
                relativeUrl.AppendFormat("?{0}", queryString);
            }

            defaultParameters["relative_url"] = relativeUrl.ToString();

            var data = batchParameter.Data;
            if (data == null)
            {
                returnResult = defaultParameters;
            }
            else
            {
                if (!(data is IDictionary<string, object>))
                {
                    data = FacebookUtils.ToDictionary(batchParameter.Data);
                }

                returnResult = FacebookUtils.Merge(defaultParameters, (IDictionary<string, object>)data);
            }

            return returnResult;
        }

        /// <summary>
        /// Processes the batch result.
        /// </summary>
        /// <param name="result">
        /// The json result.
        /// </param>
        /// <returns>
        /// Batch result.
        /// </returns>
        internal static object ProcessBatchResult(object result)
        {
            Contract.Requires(result != null);
            Contract.Ensures(Contract.Result<object>() != null);

            IList<object> list = new JsonArray();

            var resultList = (IList<object>)result;

            foreach (var row in resultList)
            {
                if (row == null)
                {
                    // row is null when omit_response_on_success = true
                    list.Add(null);
                }
                else
                {
                    var body = (string)((IDictionary<string, object>)row)["body"];
                    var exception = ExceptionFactory.GetGraphException(body);

                    object jsonObject = null;
                    if (exception == null)
                    {
                        // check for rest exception
                        jsonObject = JsonSerializer.Current.DeserializeObject(body);
                        exception = ExceptionFactory.GetRestException(jsonObject);
                    }

                    list.Add(exception ?? jsonObject);
                }
            }

            return list;
        }

        #endregion

#if (!SILVERLIGHT) // Silverlight should only have async calls

        protected T Api<T>(string path, IDictionary<string, object> parameters, HttpMethod httpMethod)
        {
            return (T)Api(path, parameters, httpMethod, typeof(T));
        }

        internal protected virtual object Api(string path, IDictionary<string, object> parameters, HttpMethod httpMethod, Type resultType)
        {
            var mergedParameters = FacebookUtils.Merge(null, parameters);

            if (!mergedParameters.ContainsKey("access_token") && !string.IsNullOrEmpty(AccessToken))
            {
                mergedParameters["access_token"] = AccessToken;
            }

            Uri requestUrl;
            string contentType;
            byte[] postData = BuildRequestData(path, mergedParameters, httpMethod, out requestUrl, out contentType);

            var jsonString = MakeRequest(httpMethod, requestUrl, postData, contentType);

            var json = JsonSerializer.Current.DeserializeObject(jsonString);

            FacebookApiException facebookApiException =
                ExceptionFactory.GetGraphException(json) ??
                ExceptionFactory.CheckForRestException(DomainMaps, requestUrl, json);

            if (facebookApiException != null)
            {
                throw facebookApiException;
            }

            return resultType == null ? json : JsonSerializer.Current.DeserializeObject(jsonString, resultType);
        }

        private static string MakeRequest(HttpMethod httpMethod, Uri requestUrl, byte[] postData, string contentType)
        {
            var request = (HttpWebRequest)WebRequest.Create(requestUrl);
            request.Method = FacebookUtils.ConvertToString(httpMethod); // Set the http method GET, POST, etc.

            if (postData != null)
            {
                request.ContentLength = postData.Length;
                request.ContentType = contentType;
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(postData, 0, postData.Length);
                }
            }

            var responseData = string.Empty;
            Exception exception = null;
            try
            {
                var response = (HttpWebResponse)request.GetResponse();
                using (var streamReader = new StreamReader(response.GetResponseStream()))
                {
                    responseData = streamReader.ReadToEnd();
                }

                response.Close();
            }
            catch (WebException ex)
            {
                exception = (Exception)ExceptionFactory.GetGraphException(ex) ?? ex;
            }
            finally
            {
                if (exception != null)
                {
                    throw exception;
                }
            }

            return responseData;
        }
#endif

        internal protected virtual void ApiAsync(string path, IDictionary<string, object> parameters, HttpMethod httpMethod, object userToken)
        {
            var mergedParameters = FacebookUtils.Merge(null, parameters);

            if (!mergedParameters.ContainsKey("access_token") && !String.IsNullOrEmpty(AccessToken))
            {
                mergedParameters["access_token"] = AccessToken;
            }

            Uri requestUrl;
            string contentType;
            byte[] postData = BuildRequestData(path, mergedParameters, httpMethod, out requestUrl, out contentType);

            var tempState = new WebClientStateContainer
            {
                UserState = userToken,
                Method = httpMethod,
                RequestUri = requestUrl
            };

            Action<string, Exception> callback =
                (json, ex) =>
                {
                    byte[] result = null;

                    if (ex == null)
                    {
                        result = Encoding.UTF8.GetBytes(json);
                    }

                    if (httpMethod == HttpMethod.Get)
                    {
                        DownloadDataCompleted(this, new DownloadDataCompletedEventArgsWrapper(ex, false, tempState, result));
                    }
                    else
                    {
                        UploadDataCompleted(this, new UploadDataCompletedEventArgsWrapper(ex, false, tempState, result));
                    }
                };

            var request = (HttpWebRequest)HttpWebRequest.Create(requestUrl);
            request.Method = FacebookUtils.ConvertToString(httpMethod); // Set the http method GET, POST, etc.

            if (request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
            {
                if (path == null && mergedParameters.ContainsKey("batch"))
                {
                    tempState.IsBatchRequest = true;
                }

                request.ContentType = contentType;
                request.BeginGetRequestStream((ar) => { RequestCallback(ar, postData, callback, tempState); }, request);
            }
            else
            {
                request.BeginGetResponse((ar) => { ResponseCallback(ar, callback, tempState); }, request);
            }
        }

        /// <summary>
        /// The asynchronous web request callback.
        /// </summary>
        /// <param name="asyncResult">The asynchronous result.</param>
        /// <param name="postData">The post data.</param>
        /// <param name="callback">The callback method.</param>
        /// <param name="state">The asynchronous state.</param>
        private static void RequestCallback(IAsyncResult asyncResult, byte[] postData, Action<string, Exception> callback, object state)
        {
            var request = (HttpWebRequest)asyncResult.AsyncState;
            using (Stream stream = request.EndGetRequestStream(asyncResult))
            {
                stream.Write(postData, 0, postData.Length);
            }

            request.BeginGetResponse((ar) => { ResponseCallback(ar, callback, state); }, request);
        }

        /// <summary>
        /// The asynchronous web response callback.
        /// </summary>
        /// <param name="asyncResult">The asynchronous result.</param>
        /// <param name="callback">The callback method.</param>
        /// <param name="state">The asynchronous state.</param>
        private static void ResponseCallback(IAsyncResult asyncResult, Action<string, Exception> callback, object state)
        {
            string result = null;
            Exception exception = null;

            try
            {
                var request = (HttpWebRequest)asyncResult.AsyncState;
                var response = (HttpWebResponse)request.EndGetResponse(asyncResult);

                using (Stream responseStream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(responseStream))
                    {
                        result = reader.ReadToEnd();
                    }
                }
            }
            catch (WebException ex)
            {
                exception = new WebExceptionWrapper(ex);
            }
            catch (Exception ex)
            {
                exception = ex;
            }
            finally
            {
                if (callback != null)
                {
                    callback(result, exception);
                }
            }
        }

        protected void OnGetCompleted(FacebookApiEventArgs args)
        {
            if (GetCompleted != null)
            {
                GetCompleted(this, args);
            }
        }

        protected void OnPostCompleted(FacebookApiEventArgs args)
        {
            if (PostCompleted != null)
            {
                PostCompleted(this, args);
            }
        }

        protected void OnDeleteCompleted(FacebookApiEventArgs args)
        {
            if (DeleteCompleted != null)
            {
                DeleteCompleted(this, args);
            }
        }

        #region Url helper methods

        /// <summary>
        /// Build the URL for api given parameters.
        /// </summary>
        /// <param name="method">
        /// The method name.
        /// </param>
        /// <returns>
        /// The Url for the given parameters.
        /// </returns>
        protected virtual Uri GetApiUrl(string method)
        {
            Contract.Requires(!String.IsNullOrEmpty(method));
            Contract.Ensures(Contract.Result<Uri>() != default(Uri));

            string name = "api";

            if (method.Equals("video.upload"))
            {
                name = "api_video";
            }

            if (FacebookUtils.ReadOnlyCalls.Contains(method))
            {
                name = "api_read";
            }

            return GetUrl(name, "restserver.php");
        }

        /// <summary>
        /// Build the URL for given domain alias, path and parameters.
        /// </summary>
        /// <param name="name">
        /// The name of the domain (from the domain maps).
        /// </param>
        /// <returns>
        /// The string of the url for the given parameters.
        /// </returns>
        protected Uri GetUrl(string name)
        {
            Contract.Requires(!String.IsNullOrEmpty(name));
            Contract.Ensures(Contract.Result<Uri>() != default(Uri));

            return GetUrl(name, string.Empty, null);
        }

        /// <summary>
        /// Build the URL for given domain alias, path and parameters.
        /// </summary>
        /// <param name="name">
        /// The name of the domain (from the domain maps).
        /// </param>
        /// <param name="path">
        /// Path (without a leading slash)
        /// </param>
        /// <returns>
        /// The string of the url for the given parameters.
        /// </returns>
        protected Uri GetUrl(string name, string path)
        {
            Contract.Requires(!String.IsNullOrEmpty(name));
            Contract.Ensures(Contract.Result<Uri>() != default(Uri));

            return GetUrl(name, path, null);
        }

        /// <summary>
        /// Build the URL for given domain alias, path and parameters.
        /// </summary>
        /// <param name="name">
        /// The name of the domain (from the domain maps).
        /// </param>
        /// <param name="parameters">
        /// Optional query parameters
        /// </param>
        /// <returns>
        /// The string of the url for the given parameters.
        /// </returns>
        protected Uri GetUrl(string name, IDictionary<string, object> parameters)
        {
            Contract.Requires(!String.IsNullOrEmpty(name));
            Contract.Ensures(Contract.Result<Uri>() != default(Uri));

            return GetUrl(name, string.Empty, parameters);
        }

        /// <summary>
        /// Build the URL for given domain alias, path and parameters.
        /// </summary>
        /// <param name="name">
        /// The name of the domain (from the domain maps).
        /// </param>
        /// <param name="path">
        /// Optional path (without a leading slash)
        /// </param>
        /// <param name="parameters">
        /// Optional query parameters
        /// </param>
        /// <returns>
        /// The string of the url for the given parameters.
        /// </returns>
        internal virtual Uri GetUrl(string name, string path, IDictionary<string, object> parameters)
        {
            Contract.Requires(!String.IsNullOrEmpty(name));
            Contract.Ensures(Contract.Result<Uri>() != default(Uri));

            return FacebookUtils.GetUrl(DomainMaps, name, path, parameters);
        }

        #endregion

        /// <summary>
        /// Builds the request post data and request uri based on the given parameters.
        /// </summary>
        /// <param name="uri">
        /// The request uri.
        /// </param>
        /// <param name="parameters">
        /// The request parameters.
        /// </param>
        /// <param name="httpMethod">
        /// The http method.
        /// </param>
        /// <param name="requestUrl">
        /// The outputted request uri.
        /// </param>
        /// <param name="contentType">
        /// The request content type.
        /// </param>
        /// <returns>
        /// The request post data.
        /// </returns>
        internal static byte[] BuildRequestData(Uri uri, IDictionary<string, object> parameters, HttpMethod httpMethod, out Uri requestUrl, out string contentType)
        {
            Contract.Requires(uri != null);
            Contract.Requires(parameters != null);

            var requestUrlBuilder = new UriBuilder(uri);

            // Set the default content type
            contentType = "application/x-www-form-urlencoded";
            byte[] postData = null;
            string queryString = string.Empty;

            if (httpMethod == HttpMethod.Get)
            {
                queryString = FacebookUtils.ToJsonQueryString(parameters);
            }
            else
            {
                if (parameters.ContainsKey("access_token"))
                {
                    queryString = string.Concat("access_token=", parameters["access_token"]);
                    parameters.Remove("access_token");
                }
                else if (parameters.ContainsKey("oauth_token"))
                {
                    queryString = string.Concat("oauth_token=", parameters["oauth_token"]);
                    parameters.Remove("oauth_token");
                }

#if SILVERLIGHT
                if (httpMethod == HttpMethod.Delete)
                {
                    parameters["method"] = "delete";
                }
#endif

                var mediaObjects = ExtractMediaObjects(parameters);
                if (mediaObjects.Count == 0)
                {
                    postData = Encoding.UTF8.GetBytes(FacebookUtils.ToJsonQueryString(parameters));
                }
                else
                {
                    string boundary = DateTime.Now.Ticks.ToString("x", CultureInfo.InvariantCulture);
                    postData = BuildMediaObjectPostData(parameters, mediaObjects, boundary);
                    contentType = string.Concat("multipart/form-data; boundary=", boundary);
                }
            }

            requestUrlBuilder.Query = queryString;
            requestUrl = requestUrlBuilder.Uri;

            return postData;
        }

        internal static IDictionary<string, FacebookMediaObject> ExtractMediaObjects(IDictionary<string, object> parameters)
        {
            var mediaObjects = new Dictionary<string, FacebookMediaObject>();

            if (parameters == null)
            {
                return mediaObjects;
            }

            foreach (var parameter in parameters)
            {
                if (parameter.Value is FacebookMediaObject)
                {
                    mediaObjects.Add(parameter.Key, (FacebookMediaObject)parameter.Value);
                }
            }

            foreach (var mediaObject in mediaObjects)
            {
                parameters.Remove(mediaObject.Key);
            }

            return mediaObjects;
        }

        /// <summary>
        /// Builds the request post data if the request contains a media object
        /// such as an image or video to upload.
        /// </summary>
        /// <param name="parameters">The request parameters without media objects.</param>
        /// <param name="mediaObjects">Media objects</param>
        /// <param name="boundary">The multipart form request boundary.</param>
        /// <returns>The request post data.</returns>
        internal static byte[] BuildMediaObjectPostData(IDictionary<string, object> parameters, IDictionary<string, FacebookMediaObject> mediaObjects, string boundary)
        {
            Contract.Requires(parameters != null);
            Contract.Requires(mediaObjects != null);
            Contract.Requires(mediaObjects.Count > 0);
            Contract.Requires(!string.IsNullOrEmpty(boundary));

            List<byte[]> postDataList = new List<byte[]>();
            int postDataLength;

            // Build up the post message header
            var sb = new StringBuilder();
            foreach (var kvp in parameters)
            {
                sb.Append(FacebookUtils.MultiPartFormPrefix).Append(boundary).Append(FacebookUtils.MultiPartNewLine);
                sb.Append("Content-Disposition: form-data; name=\"").Append(kvp.Key).Append("\"");
                sb.Append(FacebookUtils.MultiPartNewLine);
                sb.Append(FacebookUtils.MultiPartNewLine);

                // Format Object As Json And Remove leading and trailing parenthesis
                string jsonValue = FacebookUtils.ToJsonString(kvp.Value);

                sb.Append(jsonValue);
                sb.Append(FacebookUtils.MultiPartNewLine);
            }

            byte[] postHeaderBytes = Encoding.UTF8.GetBytes(sb.ToString());
            postDataList.Add(postHeaderBytes);
            postDataLength = postHeaderBytes.Length;

            foreach (var facebookMediaObject in mediaObjects)
            {
                var sbMediaObject = new StringBuilder();
                var mediaObject = facebookMediaObject.Value;

                if (mediaObject.ContentType == null || mediaObject.GetValue() == null || string.IsNullOrEmpty(mediaObject.FileName))
                {
                    throw new InvalidOperationException(Properties.Resources.MediaObjectMustHavePropertiesSetError);
                }

                sbMediaObject.Append(FacebookUtils.MultiPartFormPrefix).Append(boundary).Append(FacebookUtils.MultiPartNewLine);
                sbMediaObject.Append("Content-Disposition: form-data; name=\"").Append(facebookMediaObject.Key).Append("\"; filename=\"").Append(mediaObject.FileName).Append("\"").Append(FacebookUtils.MultiPartNewLine);
                sbMediaObject.Append("Content-Type: ").Append(mediaObject.ContentType).Append(FacebookUtils.MultiPartNewLine).Append(FacebookUtils.MultiPartNewLine);

                var mediaObjectHeaderBytes = Encoding.UTF8.GetBytes(sbMediaObject.ToString());
                postDataList.Add(mediaObjectHeaderBytes);
                postDataLength += mediaObjectHeaderBytes.Length;

                byte[] fileData = mediaObject.GetValue();

                Debug.Assert(fileData != null, "The value of FacebookMediaObject is null.");

                postDataList.Add(fileData);
                postDataLength += fileData.Length;

                var newLine = Encoding.UTF8.GetBytes(FacebookUtils.MultiPartNewLine);
                postDataList.Add(newLine);
                postDataLength += newLine.Length;
            }

            byte[] boundaryBytes = Encoding.UTF8.GetBytes(String.Concat(FacebookUtils.MultiPartNewLine, FacebookUtils.MultiPartFormPrefix, boundary, FacebookUtils.MultiPartFormPrefix, FacebookUtils.MultiPartNewLine));
            postDataList.Add(boundaryBytes);
            postDataLength += boundaryBytes.Length;

            var postData = new byte[postDataLength];
            int dstOffset = 0;
            foreach (var data in postDataList)
            {
                Buffer.BlockCopy(data, 0, postData, dstOffset, data.Length);
                dstOffset += data.Length;
            }

            return postData;
        }

        private byte[] BuildRequestData(string path, IDictionary<string, object> parameters, HttpMethod method, out Uri requestUrl, out string contentType)
        {
            parameters = parameters ?? new Dictionary<string, object>();

            path = FacebookUtils.ParseQueryParametersToDictionary(path, parameters);

            Uri baseUrl;
            if (parameters.ContainsKey("method"))
            {
                if (String.IsNullOrEmpty((string)parameters["method"]))
                {
                    throw new ArgumentException("You must specify a value for the method parameter.");
                }

                // Set the format to json
                parameters["format"] = "json-strings";
                baseUrl = GetApiUrl(parameters["method"].ToString());
            }
            else
            {
                if (!String.IsNullOrEmpty(path) && path.StartsWith("/", StringComparison.Ordinal))
                {
                    path = path.Substring(1, path.Length - 1);
                }

                if (!String.IsNullOrEmpty(path) && method == HttpMethod.Post && path.EndsWith("/videos"))
                {
                    baseUrl = GetUrl(FacebookUtils.DOMAIN_MAP_GRAPH_VIDEO, path);
                }
                else
                {
                    baseUrl = GetUrl(FacebookUtils.DOMAIN_MAP_GRAPH, path);
                }
            }

            return BuildRequestData(baseUrl, parameters, method, out requestUrl, out contentType);
        }

        internal void DownloadDataCompleted(object sender, DownloadDataCompletedEventArgsWrapper e)
        {
            string json = null;

            if (e.Error == null && e.Result != null)
            {
                json = Encoding.UTF8.GetString(e.Result, 0, e.Result.Length);
            }

            HttpMethod method;
            var args = GetApiEventArgs(e, json, out method);
            OnGetCompleted(args);
        }

        internal void UploadDataCompleted(object sender, UploadDataCompletedEventArgsWrapper e)
        {
            string json = null;

            if (e.Error == null && e.Result != null)
            {
                json = Encoding.UTF8.GetString(e.Result, 0, e.Result.Length);
            }

            HttpMethod method;
            var args = GetApiEventArgs(e, json, out method);

            if (method == HttpMethod.Post)
            {
                OnPostCompleted(args);
            }
            else if (method == HttpMethod.Delete)
            {
                OnDeleteCompleted(args);
            }
            else
            {
                throw new InvalidOperationException();
            }
        }

        private FacebookApiEventArgs GetApiEventArgs(AsyncCompletedEventArgs e, string json, out HttpMethod httpMethod)
        {
            var state = (WebClientStateContainer)e.UserState;
            httpMethod = state.Method;

            var cancelled = e.Cancelled;
            var userState = state.UserState;
            var error = e.Error;

            // Check for Graph Exception
            var webException = error as WebExceptionWrapper;
            if (webException != null)
            {
                error = ExceptionFactory.GetGraphException(webException) ?? (Exception)webException.ActualWebException;
            }

            if (error == null)
            {
                var jsonObj = JsonSerializer.Current.DeserializeObject(json);

                // we need to check for graph exception here again coz fb return 200ok
                // for https://graph.facebook.com/i_dont_exist
                error = ExceptionFactory.GetGraphException(jsonObj) ??
                        ExceptionFactory.CheckForRestException(DomainMaps, state.RequestUri, jsonObj);
            }

            var args = new FacebookApiEventArgs(error, cancelled, userState, json, state.IsBatchRequest);
            return args;
        }
    }
}